
import json 

#data_set = {"clientId": "4bb1d381-fdf2-4214-91c6-69204303168b","clientSecret": "lHr7Q~43EJvl6UgxhrKM5wELAK-xzzNwRFd6N","subscriptionId":"40106117-b501-460a-b836-6294f5cd0cdf","tennantId":"eb36d020-2c35-44de-bc7a-554cc979b26d"}
data_set = {"clientId": "e38386d9-3802-4709-a1fa-cc0c88d0a4a2",
  "clientSecret": "3ho1yD.JEZhEzn8DSesG-61F.X9ZFyPmdy",
  "subscriptionId": "40106117-b501-460a-b836-6294f5cd0cdf",
  "tenantId": "eb36d020-2c35-44de-bc7a-554cc979b26d",
  "activeDirectoryEndpointUrl": "https://login.microsoftonline.com",
  "resourceManagerEndpointUrl": "https://management.azure.com/",
  "activeDirectoryGraphResourceId": "https://graph.windows.net/",
  "sqlManagementEndpointUrl": "https://management.core.windows.net:8443/",
  "galleryEndpointUrl": "https://gallery.azure.com/",
  "managementEndpointUrl": "https://management.core.windows.net/"}

#json_object = json.loads(json_dump)

#print(json_object["clientId"])

with open("AZURE_CREDENTIALS.json", "w") as write_file:
    json.dump(data_set, write_file) 
